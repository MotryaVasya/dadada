package com.example.forigorbest;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText name;
    EditText password1;
    Button button;
    Table table;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        name = findViewById(R.id.editTextText);
        password1 = findViewById(R.id.editPassword);
        button = findViewById(R.id.button);
        table = new Table(this);
        //Acount a = new Acount(table.selectAll().size()+1,"MNB1787mnb", "name");
        //table.insert(a);
    }
    public void OnClick(View v)
    {
        int count = table.select("select * from Acounts where Name = " + name.getText()).size();
        if (count == 1)
        {
            Intent intent = new Intent(this, SecondActivity.class);
            startActivity(intent);
        }

    }
    public void CreateAcount(View w) {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}