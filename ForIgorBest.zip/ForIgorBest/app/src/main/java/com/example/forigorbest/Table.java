package com.example.forigorbest;


import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class Table {
    SQLiteDatabase database;
    public Table (Context context){
        database = context.openOrCreateDatabase("App.db", Context.MODE_PRIVATE, null);
        String query = "create table if not exists Acounts (id int primary key autoincrement, password text, name text);";
        database.execSQL(query);
    }

    public ArrayList<Acount> select(String query){
        ArrayList<Acount> acountList = new ArrayList<>();
        Cursor cursor= database.rawQuery(query,null);
        while(cursor.moveToNext()) {
            acountList.add(new Acount(cursor.getInt(0), cursor.getString(1), cursor.getString(2)));
        }
        return acountList;
    }


    public void insert(Acount acount) {
        database.execSQL("INSERT INTO Acounts VALUES ('"+ acount.getId()+ "', '"+ acount.getPassword()+ "', '"+ acount.getName()+ "');");

    }
    public void delete(int Id){
        String query = "delete from Acounts where id = "+Id;
        database.rawQuery(query, null);
    }
    public void update(Acount acount){
        String query = "updete Acounts set name ="+"'"+acount.getPassword()+"where id="+acount.getId();
        database.execSQL(query);
    }
    public ArrayList<Acount> selectAll(){ return select("select * from Acounts"); }

}
