public class saca extends AppCompatActivity {
    EditText editTextLogin, editTextPassword;
    Button buttonLogin;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Найдем элементы на экране
        editTextLogin = findViewById(R.id.editTextLogin);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);

        // Создаем или открываем базу данных
        db = openOrCreateDatabase("UsersDB", MODE_PRIVATE, null);

        // Создаем таблицу, если ее еще нет
        db.execSQL("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, login TEXT, password TEXT);");

        // Вставим несколько тестовых данных
        insertTestUsers();

        // Устанавливаем обработчик нажатия на кнопку
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login = editTextLogin.getText().toString();
                String password = editTextPassword.getText().toString();

                if (checkLogin(login, password)) {
                    Toast.makeText(MainActivity.this, "Успешный вход", Toast.LENGTH_SHORT).show();
                    // Переход на другое окно
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Вставка тестовых данных (если нужно)
    private void insertTestUsers() {
        // Проверим, есть ли данные, и вставим, если база пустая
        Cursor cursor = db.rawQuery("SELECT * FROM users", null);
        if (cursor.getCount() == 0) {
            db.execSQL("INSERT INTO users (login, password) VALUES ('user1', 'password1');");
            db.execSQL("INSERT INTO users (login, password) VALUES ('user2', 'password2');");
        }
        cursor.close();
    }

    // Метод для проверки логина и пароля
    private boolean checkLogin(String login, String password) {
        // Подготовим запрос к базе данных
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE login=? AND password=?", new String[]{login, password});
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null) {
            db.close(); // Закрытие базы данных при уничтожении активности
        }
    }
}